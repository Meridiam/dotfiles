export PATH="$TESTDIR/..:$TESTDIR/bin:$PATH"
